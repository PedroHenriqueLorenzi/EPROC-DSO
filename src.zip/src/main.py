from controller.controladorSistema import ControladorSistema

if __name__ == "__main__":
    sistema = ControladorSistema()
    sistema.inicializar()